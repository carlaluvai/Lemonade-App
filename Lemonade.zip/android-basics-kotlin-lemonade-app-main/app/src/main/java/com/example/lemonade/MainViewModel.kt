package com.example.lemonade

class MainViewModel {
}